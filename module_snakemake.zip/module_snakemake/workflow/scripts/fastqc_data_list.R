library(tidyverse)
log <- file(snakemake@log[[1]], open="wt")
sink(log)
sink(log, type="message")

fastqc_files <- snakemake@input[['fastqc_data_files']]
df_fastq <- as.data.frame(fastqc_files)
write.csv(df_fastq, snakemake@output[["data_list"]], row.names=FALSE)
print("Tabela gerada com sucesso")