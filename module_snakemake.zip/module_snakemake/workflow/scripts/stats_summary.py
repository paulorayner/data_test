import pandas as pd
import logging
import sys 

# Criação do Log tirar comentário das linhas abaixo para gerar o log
sys.stderr = open(snakemake.log[0], "w")
sys.stdout = open(snakemake.log[0], "w")


fastqc_data = snakemake.input["fastqc_data_files"]

stats_params = ["Total Sequences", "Sequence length", 
"Per base sequence quality","Per sequence quality scores","Filename"]

for file in fastqc_data:
    fastqc_file=open(file, "r")
    lines=fastqc_file.readlines()
    data_stats = []
    for line in lines:
        for i in stats_params:
            if i in line:
                data_stats.append((line.replace(">>","",).replace("\n", "")).split("\t"))
    df_stats_summary = pd.DataFrame(data_stats, columns=["Parameters", "Values"])
    df_stats_summary.to_csv(snakemake.output["stats_summary"], sep=",", index=False)
    sample_id = data_stats[0][1]
    print(f'Arquivo summary_stats para {sample_id} gerado com sucesso')

