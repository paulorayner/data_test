# Criação do Log tirar comentário para gerar o log
import pandas as pd 
import sys

sys.stderr = open(snakemake.log[0], "w")
sys.stdout = open(snakemake.log[0], "w")

fastqc_data = snakemake.input["fastqc_data_files"]

df_fastqc_data = pd.DataFrame(fastqc_data, columns=["fastqc_files_path"])
df_fastqc_data.to_csv(snakemake.output["data_list"], index=False)

print("Lista criada com sucesso")